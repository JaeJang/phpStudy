const BUTTON_STYLE_ENABLE = 'btn-lg btn-primary';
const BUTTON_STYLE_DISABLE_SUCESS = 'btn btn-success';
const BUTTON_STYLE_DISABLE_FAIL = 'btn btn-danger';
/*
const WORD_LIST = ['list', 'wonder','world', 'double','place','fast','drive','read','length','size',
					'electricity','tattoo'];  
const DEF = ['a series of names or other items written or printed together in a meaningful grouping or sequence so as to constitute a record.', 
			'To think or speculate curiously',
			'The earth or globe, considered as a planet.',
			'Twice as large, heavy, strong.',
			'A particular portion of space, whether of definite or indefinite extent.',
			'Moving or able to move, operate, function, or take effect quickly',
			'To send, expel, or otherwise cause to move by force or compulsion',
			'To look at carefully so as to understand the meaning of (something written, printed, etc.)',
			'The longest extent of anything as measured from end to end',
			'The spatial dimensions, proportions, magnitude, or bulk of anything',
			'is the set of physical phenomena associated with the presence and motion of electric charge.',
			'A form of body modification where a design is made by inserting ink'
			];
	*/		
const WORD_LIST = ['electricity', 'tattoo'];
const DEF = ['is the set of physical phenomena associated with the presence and motion of electric charge.',
				'A form of body modification where a design is made by inserting ink'];

